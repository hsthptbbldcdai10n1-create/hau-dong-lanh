Bo anh vao thu muc nay (jpg, png hoac webp):
  hero.jpg     - nen banner trang chu
  product.jpg  - anh san pham chinh (trang chu + trang San pham)
  product2.jpg ... product7.jpg - anh them cho muc 'Hinh anh san pham'
  factory.jpg  - anh nha may (trang Gioi thieu)
